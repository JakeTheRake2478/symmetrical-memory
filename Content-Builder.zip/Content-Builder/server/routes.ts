import type { Express } from "express";
import { createServer, type Server } from "http";
import express from "express";
import { storage } from "./storage";
import { sanitizeEmbedCode, insertTileSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";

// Configure multer for image uploads
const uploadDir = path.resolve("./uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      cb(null, `${randomUUID()}${ext}`);
    },
  }),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only JPEG, PNG, GIF, and WebP are allowed."));
    }
  },
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Serve uploaded images securely using express.static
  app.use("/uploads", express.static(uploadDir));

  // Get all tiles
  app.get("/api/tiles", async (req, res) => {
    try {
      const tiles = await storage.getTiles();
      res.json(tiles);
    } catch (error) {
      console.error("Error fetching tiles:", error);
      res.status(500).json({ message: "Failed to fetch tiles" });
    }
  });

  // Get single tile
  app.get("/api/tiles/:id", async (req, res) => {
    try {
      const tile = await storage.getTile(req.params.id);
      if (!tile) {
        return res.status(404).json({ message: "Tile not found" });
      }
      res.json(tile);
    } catch (error) {
      console.error("Error fetching tile:", error);
      res.status(500).json({ message: "Failed to fetch tile" });
    }
  });

  // Create new tile with image upload
  app.post("/api/tiles", upload.single("image"), async (req, res) => {
    try {
      const { title, embedCode } = req.body;

      // Validate required fields
      if (!title || !embedCode) {
        return res.status(400).json({ message: "Title and embed code are required" });
      }

      // Sanitize and validate embed URL
      const embedUrl = sanitizeEmbedCode(embedCode);
      if (!embedUrl) {
        return res.status(400).json({ 
          message: "Invalid embed URL. Only safe embed sources are allowed (YouTube, Vimeo, CodePen, etc.)" 
        });
      }

      // Get image URL if uploaded
      let imageUrl = "";
      if (req.file) {
        imageUrl = `/uploads/${req.file.filename}`;
      }

      // Validate with schema
      const parsed = insertTileSchema.safeParse({
        title,
        imageUrl,
        embedUrl,
      });

      if (!parsed.success) {
        return res.status(400).json({ 
          message: "Invalid tile data",
          errors: parsed.error.errors 
        });
      }

      const tile = await storage.createTile(parsed.data);
      res.status(201).json(tile);
    } catch (error) {
      console.error("Error creating tile:", error);
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create tile" });
      }
    }
  });

  // Delete tile
  app.delete("/api/tiles/:id", async (req, res) => {
    try {
      const tile = await storage.getTile(req.params.id);
      if (!tile) {
        return res.status(404).json({ message: "Tile not found" });
      }

      // Delete associated image if exists
      if (tile.imageUrl && tile.imageUrl.startsWith("/uploads/")) {
        const filename = path.basename(tile.imageUrl);
        const imagePath = path.join(uploadDir, filename);
        if (fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
        }
      }

      await storage.deleteTile(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting tile:", error);
      res.status(500).json({ message: "Failed to delete tile" });
    }
  });

  return httpServer;
}
