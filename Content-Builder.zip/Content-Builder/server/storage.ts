import { type ContentTile, type InsertTile } from "@shared/schema";
import { randomUUID } from "crypto";
import fs from "fs";
import path from "path";

const DATA_FILE = "./data/tiles.json";

export interface IStorage {
  getTiles(): Promise<ContentTile[]>;
  getTile(id: string): Promise<ContentTile | undefined>;
  createTile(tile: InsertTile): Promise<ContentTile>;
  deleteTile(id: string): Promise<boolean>;
}

function ensureDataDir() {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function loadTiles(): ContentTile[] {
  ensureDataDir();
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (error) {
    console.error("Error loading tiles:", error);
  }
  return [];
}

function saveTiles(tiles: ContentTile[]) {
  ensureDataDir();
  fs.writeFileSync(DATA_FILE, JSON.stringify(tiles, null, 2));
}

export class MemStorage implements IStorage {
  private tiles: Map<string, ContentTile>;

  constructor() {
    this.tiles = new Map();
    // Load persisted tiles on startup
    const persistedTiles = loadTiles();
    for (const tile of persistedTiles) {
      this.tiles.set(tile.id, tile);
    }
  }

  private persistTiles() {
    saveTiles(Array.from(this.tiles.values()));
  }

  async getTiles(): Promise<ContentTile[]> {
    return Array.from(this.tiles.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  async getTile(id: string): Promise<ContentTile | undefined> {
    return this.tiles.get(id);
  }

  async createTile(insertTile: InsertTile): Promise<ContentTile> {
    const id = randomUUID();
    const tile: ContentTile = { 
      ...insertTile, 
      id, 
      createdAt: Date.now() 
    };
    this.tiles.set(id, tile);
    this.persistTiles();
    return tile;
  }

  async deleteTile(id: string): Promise<boolean> {
    const result = this.tiles.delete(id);
    if (result) {
      this.persistTiles();
    }
    return result;
  }
}

export const storage = new MemStorage();
