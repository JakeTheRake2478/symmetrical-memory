# Content Hub

## Overview

A modern, interactive content hub web application for browsing and interacting with embeddable content tiles. Users can search, favorite, and view content in fullscreen mode. The app features a clean tile-based interface with theme switching (light/dark mode) and a hidden admin panel for content management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and data fetching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming (light/dark mode support)
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **API Design**: RESTful API endpoints under `/api` prefix
- **File Uploads**: Multer for handling image uploads to `/uploads` directory
- **Development Server**: Vite dev server with HMR integration for development

### Data Storage
- **Primary Storage**: JSON file-based persistence (`data/tiles.json`)
- **Database Config**: Drizzle ORM configured for PostgreSQL (schema defined but JSON storage currently in use)
- **User Preferences**: localStorage for favorites and theme preferences (client-side persistence)

### Key Design Patterns
- **Shared Schema**: Zod schemas in `/shared` directory for type-safe validation across client and server
- **Path Aliases**: `@/` for client source, `@shared/` for shared code
- **Component Structure**: Feature components in `/client/src/components`, UI primitives in `/client/src/components/ui`

### Security Features
- **Embed URL Validation**: Whitelist of allowed embed domains (YouTube, Vimeo, CodePen, etc.)
- **Input Sanitization**: Script tag stripping and iframe validation for admin uploads
- **Hidden Admin Access**: Admin panel accessible via secret keyboard shortcut (Ctrl+Shift+A) or direct `/admin` route

## External Dependencies

### Database
- PostgreSQL via Drizzle ORM (configured in `drizzle.config.ts`, requires `DATABASE_URL` environment variable)
- JSON file storage as fallback/current implementation

### UI Libraries
- Radix UI primitives (dialog, dropdown, toast, etc.)
- Embla Carousel for carousel functionality
- Lucide React for icons
- Vaul for drawer components
- cmdk for command palette

### Build & Development
- Vite with React plugin
- esbuild for server bundling
- TypeScript for type checking
- Tailwind CSS with PostCSS

### Allowed Embed Domains
The application whitelists specific domains for iframe embeds including YouTube, Vimeo, CodePen, CodeSandbox, Figma, Google Docs, Spotify, SoundCloud, Twitch, and others defined in `shared/schema.ts`.