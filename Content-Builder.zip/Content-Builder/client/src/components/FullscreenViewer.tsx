import { useEffect, useCallback } from "react";
import { X, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ContentTile } from "@shared/schema";

interface FullscreenViewerProps {
  tile: ContentTile | null;
  onClose: () => void;
}

export function FullscreenViewer({ tile, onClose }: FullscreenViewerProps) {
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === "Escape") {
      onClose();
    }
  }, [onClose]);

  useEffect(() => {
    if (tile) {
      document.addEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [tile, handleKeyDown]);

  if (!tile) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/90 animate-fade-in flex flex-col"
      data-testid="fullscreen-viewer"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/50 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <ExternalLink className="h-5 w-5 text-white/70" />
          <h2 className="text-white font-medium truncate max-w-md" data-testid="text-fullscreen-title">
            {tile.title}
          </h2>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          data-testid="button-close-fullscreen"
          className="text-white hover:bg-white/10"
        >
          <X className="h-5 w-5" />
          <span className="sr-only">Close fullscreen</span>
        </Button>
      </div>
      
      {/* Content */}
      <div className="flex-1 p-4">
        <iframe
          src={tile.embedUrl}
          title={tile.title}
          className="w-full h-full rounded-md border-0 bg-white"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          sandbox="allow-scripts allow-same-origin allow-popups allow-forms allow-presentation"
          data-testid="iframe-embed"
        />
      </div>
    </div>
  );
}
