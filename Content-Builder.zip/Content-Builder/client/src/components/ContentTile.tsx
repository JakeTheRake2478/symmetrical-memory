import { Heart, Maximize2, ExternalLink } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { ContentTile as ContentTileType } from "@shared/schema";

interface ContentTileProps {
  tile: ContentTileType;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  onFullscreen: () => void;
  animationDelay?: number;
}

export function ContentTile({ 
  tile, 
  isFavorite, 
  onToggleFavorite, 
  onFullscreen,
  animationDelay = 0 
}: ContentTileProps) {
  return (
    <Card 
      className="group relative overflow-visible flex flex-col animate-fade-in opacity-0 hover-elevate active-elevate-2"
      style={{ animationDelay: `${animationDelay}ms` }}
      data-testid={`card-tile-${tile.id}`}
    >
      <div className="relative aspect-video overflow-hidden rounded-t-md bg-muted">
        {tile.imageUrl ? (
          <img
            src={tile.imageUrl}
            alt={tile.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/30">
            <ExternalLink className="h-12 w-12 text-primary/50" />
          </div>
        )}
        
        {/* Overlay buttons */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-200 pointer-events-none">
          <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-auto z-10">
            <Button
              variant="secondary"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite();
              }}
              data-testid={`button-favorite-${tile.id}`}
              className="h-8 w-8 bg-white/90 dark:bg-black/70 backdrop-blur-sm border-0"
            >
              <Heart 
                className={`h-4 w-4 transition-all ${isFavorite ? 'fill-red-500 text-red-500' : 'text-muted-foreground'}`} 
              />
              <span className="sr-only">{isFavorite ? 'Remove from favorites' : 'Add to favorites'}</span>
            </Button>
            <Button
              variant="secondary"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                onFullscreen();
              }}
              data-testid={`button-fullscreen-${tile.id}`}
              className="h-8 w-8 bg-white/90 dark:bg-black/70 backdrop-blur-sm border-0"
            >
              <Maximize2 className="h-4 w-4" />
              <span className="sr-only">View fullscreen</span>
            </Button>
          </div>
        </div>
        
        {/* Favorite indicator */}
        {isFavorite && (
          <div className="absolute top-2 left-2">
            <div className="bg-red-500 rounded-full p-1">
              <Heart className="h-3 w-3 fill-white text-white" />
            </div>
          </div>
        )}
      </div>
      
      <div className="p-4 flex-1 flex flex-col">
        <h3 
          className="font-medium text-foreground line-clamp-2 leading-snug"
          data-testid={`text-title-${tile.id}`}
        >
          {tile.title}
        </h3>
      </div>
      
      {/* Click area for fullscreen */}
      <button
        onClick={onFullscreen}
        className="absolute inset-0 cursor-pointer opacity-0 z-0"
        aria-label={`Open ${tile.title} in fullscreen`}
      />
    </Card>
  );
}
