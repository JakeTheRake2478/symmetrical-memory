import { useState, useMemo, useEffect, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Layers, Heart, Loader2 } from "lucide-react";
import { ContentTile } from "@/components/ContentTile";
import { SearchBar } from "@/components/SearchBar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { FullscreenViewer } from "@/components/FullscreenViewer";
import { useFavorites } from "@/hooks/use-favorites";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import type { ContentTile as ContentTileType } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTile, setSelectedTile] = useState<ContentTileType | null>(null);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const { favorites, toggleFavorite, isFavorite } = useFavorites();
  const [, setLocation] = useLocation();
  
  // Secret key combo to access admin panel (Ctrl+Shift+A)
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.ctrlKey && e.shiftKey && e.key === "A") {
      e.preventDefault();
      setLocation("/admin");
    }
  }, [setLocation]);
  
  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  const { data: tiles = [], isLoading, error } = useQuery<ContentTileType[]>({
    queryKey: ["/api/tiles"],
  });

  const filteredAndSortedTiles = useMemo(() => {
    let result = [...tiles];
    
    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      result = result.filter((tile) =>
        tile.title.toLowerCase().includes(query)
      );
    }
    
    // Filter favorites only
    if (showFavoritesOnly) {
      result = result.filter((tile) => favorites.has(tile.id));
    }
    
    // Sort: favorites first, then by creation date (newest first)
    result.sort((a, b) => {
      const aFav = favorites.has(a.id);
      const bFav = favorites.has(b.id);
      if (aFav && !bFav) return -1;
      if (!aFav && bFav) return 1;
      return b.createdAt - a.createdAt;
    });
    
    return result;
  }, [tiles, searchQuery, showFavoritesOnly, favorites]);

  const favoritesCount = useMemo(() => {
    return tiles.filter((tile) => favorites.has(tile.id)).length;
  }, [tiles, favorites]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary text-primary-foreground">
                <Layers className="h-5 w-5" />
              </div>
              <h1 className="text-xl font-semibold hidden sm:block">Content Hub</h1>
            </div>
            
            <div className="flex items-center gap-2 flex-1 justify-center max-w-md">
              <SearchBar 
                value={searchQuery} 
                onChange={setSearchQuery}
                placeholder="Search content..."
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant={showFavoritesOnly ? "default" : "outline"}
                size="sm"
                onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
                data-testid="button-toggle-favorites"
                className="gap-2"
              >
                <Heart className={`h-4 w-4 ${showFavoritesOnly ? 'fill-current' : ''}`} />
                <span className="hidden sm:inline">Favorites</span>
                {favoritesCount > 0 && (
                  <span className="bg-primary-foreground/20 px-1.5 py-0.5 rounded text-xs">
                    {favoritesCount}
                  </span>
                )}
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Loading State */}
        {isLoading && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="aspect-video rounded-md" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            ))}
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
              <Layers className="h-8 w-8 text-destructive" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Failed to load content</h2>
            <p className="text-muted-foreground max-w-md">
              Something went wrong while loading the content. Please try refreshing the page.
            </p>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !error && filteredAndSortedTiles.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              {showFavoritesOnly ? (
                <Heart className="h-8 w-8 text-muted-foreground" />
              ) : (
                <Layers className="h-8 w-8 text-muted-foreground" />
              )}
            </div>
            <h2 className="text-xl font-semibold mb-2">
              {showFavoritesOnly 
                ? "No favorites yet" 
                : searchQuery 
                  ? "No results found" 
                  : "No content available"
              }
            </h2>
            <p className="text-muted-foreground max-w-md">
              {showFavoritesOnly
                ? "Click the heart icon on any tile to add it to your favorites."
                : searchQuery
                  ? `No content matches "${searchQuery}". Try a different search term.`
                  : "Content tiles will appear here once they're added."
              }
            </p>
            {(showFavoritesOnly || searchQuery) && (
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {
                  setShowFavoritesOnly(false);
                  setSearchQuery("");
                }}
                data-testid="button-clear-filters"
              >
                Clear filters
              </Button>
            )}
          </div>
        )}

        {/* Content Grid */}
        {!isLoading && !error && filteredAndSortedTiles.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAndSortedTiles.map((tile, index) => (
              <ContentTile
                key={tile.id}
                tile={tile}
                isFavorite={isFavorite(tile.id)}
                onToggleFavorite={() => toggleFavorite(tile.id)}
                onFullscreen={() => setSelectedTile(tile)}
                animationDelay={Math.min(index * 50, 300)}
              />
            ))}
          </div>
        )}
      </main>

      {/* Fullscreen Viewer */}
      <FullscreenViewer
        tile={selectedTile}
        onClose={() => setSelectedTile(null)}
      />
    </div>
  );
}
