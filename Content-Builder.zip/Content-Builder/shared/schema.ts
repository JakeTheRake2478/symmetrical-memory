import { z } from "zod";

// Content Tile Schema
export const contentTileSchema = z.object({
  id: z.string(),
  title: z.string().min(1, "Title is required"),
  imageUrl: z.string(),
  embedUrl: z.string().min(1, "Embed URL is required"),
  createdAt: z.number(),
});

export const insertTileSchema = contentTileSchema.omit({ id: true, createdAt: true });

export type ContentTile = z.infer<typeof contentTileSchema>;
export type InsertTile = z.infer<typeof insertTileSchema>;

// Validate iframe URL - allow any valid URL
export function isValidEmbedUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    // Allow any http or https URL
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

// Sanitize iframe embed code - extract src URL and strip dangerous content
export function sanitizeEmbedCode(input: string): string | null {
  // If it's already a URL, validate and return
  if (input.startsWith('http://') || input.startsWith('https://')) {
    return isValidEmbedUrl(input) ? input : null;
  }
  
  // Try to extract src from iframe tag
  const srcMatch = input.match(/src=["']([^"']+)["']/i);
  if (srcMatch && srcMatch[1]) {
    const url = srcMatch[1];
    return isValidEmbedUrl(url) ? url : null;
  }
  
  return null;
}
